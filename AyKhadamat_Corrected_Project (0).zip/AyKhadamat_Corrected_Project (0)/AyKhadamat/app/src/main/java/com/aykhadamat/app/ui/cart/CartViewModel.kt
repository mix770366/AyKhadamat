package com.aykhadamat.app.ui.cart

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*

data class CartItem(
    val productId: String,
    val title: String,
    val unitPrice: Double,
    val quantity: Int
)

data class CartUiState(
    val items: List<CartItem> = emptyList(),
    val notes: String = "",
    val isVipDelivery: Boolean = false
)

class CartViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CartUiState())
    val uiState: StateFlow<CartUiState> = _uiState.asStateFlow()

    val totalPrice: StateFlow<Double> = _uiState.map { state ->
        state.items.sumOf { it.unitPrice * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addItem(productId: String, title: String, price: Double) {
        _uiState.update { currentState ->
            val existingIndex = currentState.items.indexOfFirst { it.productId == productId }
            val updatedItems = currentState.items.toMutableList()
            if (existingIndex >= 0) {
                val current = updatedItems[existingIndex]
                updatedItems[existingIndex] = current.copy(quantity = current.quantity + 1)
            } else {
                updatedItems.add(CartItem(productId, title, price, 1))
            }
            currentState.copy(items = updatedItems)
        }
    }

    fun updateQuantity(productId: String, delta: Int) {
        _uiState.update { currentState ->
            val updatedList = currentState.items.mapNotNull { item ->
                if (item.productId == productId) {
                    val newQty = item.quantity + delta
                    if (newQty > 0) item.copy(quantity = newQty) else null
                } else item
            }
            currentState.copy(items = updatedList)
        }
    }
}