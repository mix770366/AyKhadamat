package com.aykhadamat.app.ui.components

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.aykhadamat.app.data.repository.StoreItem

@Composable
fun StoresListContent(
    stores: List<StoreItem>,
    onStoreSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(modifier = modifier) {
        items(
            items = stores,
            key = { store -> store.id }
        ) { store ->
            Card(
                onClick = { onStoreSelected(store.id) }
            ) {
                Text(text = store.name, style = MaterialTheme.typography.titleMedium)
                Text(text = store.category, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}