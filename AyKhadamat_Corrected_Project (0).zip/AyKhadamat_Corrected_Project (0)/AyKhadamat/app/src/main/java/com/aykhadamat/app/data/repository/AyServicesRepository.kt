package com.aykhadamat.app.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.dispatchers.Dispatchers
import kotlinx.coroutines.withContext

sealed class NetworkResult<out T> {
    data class Success<out T>(val data: T) : NetworkResult<T>()
    data class Error(val exception: Throwable, val cachedData: Any? = null) : NetworkResult<Nothing>()
    object Loading : NetworkResult<Nothing>()
}

data class StoreItem(
    val id: String,
    val name: String,
    val category: String,
    val isAvailable: Boolean
)

class AyServicesRepository {

    fun getStoresByService(serviceId: String): Flow<NetworkResult<List<StoreItem>>> = flow {
        emit(NetworkResult.Loading)
        try {
            val remoteStores = fetchFromNetwork(serviceId)
            emit(NetworkResult.Success(remoteStores))
        } catch (e: Exception) {
            val cachedStores = getLocalCachedStores(serviceId)
            emit(NetworkResult.Error(exception = e, cachedData = cachedStores))
        }
    }

    private suspend fun fetchFromNetwork(serviceId: String): List<StoreItem> = withContext(Dispatchers.IO) {
        listOf(
            StoreItem("1", "مطعم المائدة - إب", "restaurants", true),
            StoreItem("2", "صيدلية الأمل 24/7", "pharmacy", true)
        )
    }

    private fun getLocalCachedStores(serviceId: String): List<StoreItem> {
        return listOf(
            StoreItem("1", "مطعم المائدة (محفوظ محلياً)", "restaurants", true)
        )
    }
}