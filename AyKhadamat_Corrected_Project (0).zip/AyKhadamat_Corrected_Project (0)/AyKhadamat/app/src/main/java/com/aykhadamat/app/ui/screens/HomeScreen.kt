package com.aykhadamat.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.aykhadamat.app.data.repository.StoreItem
import com.aykhadamat.app.ui.components.StoresListContent

@Composable
fun HomeScreen(
    onStoreClick: (String) -> Unit
) {
    val sampleStores = listOf(
        StoreItem("1", "مطعم المائدة - إب", "restaurants", true),
        StoreItem("2", "صيدلية الأمل 24/7", "pharmacy", true)
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "تطبيق أي خدمات - إب")
        StoresListContent(
            stores = sampleStores,
            onStoreSelected = onStoreClick
        )
    }
}