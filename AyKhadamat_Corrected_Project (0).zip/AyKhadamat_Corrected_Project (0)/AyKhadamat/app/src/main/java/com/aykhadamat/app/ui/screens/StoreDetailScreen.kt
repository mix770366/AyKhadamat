package com.aykhadamat.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun StoreDetailScreen(
    storeId: String,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "تفاصيل المتجر: $storeId")
        Button(onClick = onBack) {
            Text(text = "عودة")
        }
    }
}